// package
package a.b.c.ch3;

// import

public class ExCast_5 {

	// ���
	// �������
	// ������

	// �Լ�

	// main() �Լ� : ���α׷� ������
	public static void main(String[] args) {
	// TODO Auto-generated method stub.

		String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		
		char c0 = str.charAt(0);
		System.out.println("\nInteger.toBinaryString(c0) >>> : " + Integer.toBinaryString(c0));
		System.out.println("Integer.toOctalString(c0) >>> : " + Integer.toOctalString(c0));
		System.out.println("char c0 >>> : " + c0);
		System.out.println("Integer.toHexString(c0) >>> : \n" + Integer.toHexString(c0));

		char c1 = str.charAt(1);
		System.out.println("Integer.toBinaryString(c1) >>> : " + Integer.toBinaryString(c1));
		System.out.println("Integer.toOctalString(c1) >>> : " + Integer.toOctalString(c1));
		System.out.println("char c1 >>> : " + c1);
		System.out.println("Integer.toHexString(c1) >>> : \n" + Integer.toHexString(c1));

		char c2 = str.charAt(2);
		System.out.println("Intnger.toBinaryString(c2) >>> : " + Integer.toBinaryString(c2));
		System.out.println("Integer.toOctalString(c2) >>> : " + Integer.toOctalString(c2));
		System.out.println("char c2 >>> : " + c2);
		System.out.println("Integer.toHexString(c2) >>> : \n" + Integer.toHexString(c2));
		
		char c3 = str.charAt(3);
		System.out.println("Integer.toBinaryString(c3) >>> : " + Integer.toBinaryString(c3));
		System.out.println("Integer.toOctalString(c3) >>> : " + Integer.toOctalString(c3));
		System.out.println("char c3 >>> : " + c3);
		System.out.println("Integer.toHexString(c3) >>> : \n" + Integer.toHexString(c3));

		char c4 = str.charAt(4);
		System.out.println("Integer.toBinaryString(c4) >>> : " + Integer.toBinaryString(c4));
		System.out.println("Integer.toOctalString(c4) >>> : " + Integer.toOctalString(c4));
		System.out.println("char c4 >>> : " + c4);
		System.out.println("Integer.toHexString(c4) >>> : \n" + Integer.toHexString(c4));

		char c5 = str.charAt(5);
		System.out.println("Integer.toBinaryString(c5) >>> : " + Integer.toBinaryString(c5));
		System.out.println("Integer.toOctalStrint(c5) >>> : " + Integer.toOctalString(c5));
		System.out.println("char c5 >>> : " + c5);
		System.out.println("Integer.toHexString(c5) >>> : \n" + Integer.toHexString(c5));

		char c6 = str.charAt(6);
		System.out.println("Integer.toBinaryStrint(c6) >>> : " + Integer.toBinaryString(c6));
		System.out.println("Integer.toOctalString(c6) >>> : " + Integer.toOctalString(c6));
		System.out.println("char c6 >>> : " + c6);
		System.out.println("Integer.toHexString(c6) >>> : \n" + Integer.toHexString(c6));

		char c7 = str.charAt(7);
		System.out.println("Integer.toBinaryString(c7) >>> : " + Integer.toBinaryString(c7));
		System.out.println("Integer.toOctalString(c7) >>> : " + Integer.toOctalString(c7));
		System.out.println("char c7 >>> : " + c7);
		System.out.println("Integer.toHexString(c7) >>> : \n" + Integer.toHexString(c7));

		char c8 = str.charAt(8);
		System.out.println("Integer.toBinaryString(c8) >>> : " + Integer.toBinaryString(c8));
		System.out.println("Integer.toOctalString(c8) >>> : " + Integer.toOctalString(c8));
		System.out.println("char c8 >>> : " + c8);
		System.out.println("Integer.toHexString(c8) >>> : \n" + Integer.toHexString(c8));

		char c9 = str.charAt(9);
		System.out.println("Integer.toBinaryString(c9) >>> : " + Integer.toBinaryString(c9));
		System.out.println("Integer.toOctalString(c9) >>> : " + Integer.toOctalString(c9));
		System.out.println("char c9 >>> : " + c9);
		System.out.println("Integer.toHexString(c9) >>> : \n" + Integer.toHexString(c9));

		char c10 = str.charAt(10);
		System.out.println("Integer.toBinaryString(c10) >>> : " + Integer.toBinaryString(c10));
		System.out.println("Integer.toOctalString(c10) >>> : " + Integer.toOctalString(c10));
		System.out.println("char c10 >>> : " + c10);
		System.out.println("Integer.toHexString(c10) >>> : \n" + Integer.toHexString(c10));

		char c11 = str.charAt(11);
		System.out.println("Integer.toBinaryString(c11) >>> : " + Integer.toBinaryString(c11));
		System.out.println("Integer.toOctalString(c11) >>> : " + Integer.toOctalString(c11));
		System.out.println("char c11 >>> : " + c11);
		System.out.println("Integer.toHexString(c11) >>> : \n" + Integer.toHexString(c11));

		char c12 = str.charAt(12);
		System.out.println("Integer.toBinaryString(c12) >>> : " + Integer.toBinaryString(c12));
		System.out.println("Integer.toOctalString(c12) >>> : " + Integer.toOctalString(c12));
		System.out.println("char c12 >>> : " + c12);
		System.out.println("Integer.toHexString(c12) >>> : \n" + Integer.toHexString(c12));

		char c13 = str.charAt(13);
		System.out.println("Integer.toBinaryString(c13) >>> : " + Integer.toBinaryString(c13));
		System.out.println("Integer.toOctalString(c13) >>> : " + Integer.toOctalString(c13));
		System.out.println("char c13 >>> : " + c13);
		System.out.println("Integer.toHexString(c13) >>> : \n" + Integer.toHexString(c13));

		char c14 = str.charAt(14);
		System.out.println("Integer.toBinaryString(c14) >>> : " + Integer.toBinaryString(c14));
		System.out.println("Integer.toOctalString(c14) >>> : " + Integer.toOctalString(c14));
		System.out.println("char c14 >>> : " + c14);
		System.out.println("Integer.toHexString(c14) >>> : \n" + Integer.toHexString(c14));

		char c15 = str.charAt(15);
		System.out.println("Integer.toBinaryString(c15) >>> : " + Integer.toBinaryString(c15));
		System.out.println("Integer.toOctalString(c15) >>> : " + Integer.toOctalString(c15));
		System.out.println("char c15 >>> : " + c15);
		System.out.println("Integer.toHexString(c15) >>> : \n" + Integer.toHexString(c15));

		char c16 = str.charAt(16);
		System.out.println("Integer.toBinaryString(c16) >>> : " + Integer.toBinaryString(c16));
		System.out.println("Integer.tiOctalString(c16) >>> : " + Integer.toOctalString(c16));
		System.out.println("char c16 >>> : " + c16);
		System.out.println("Integer.toHexString(c16) >>> : \n" + Integer.toHexString(c16));

		char c17 = str.charAt(17);
		System.out.println("Integer.toBinaryString(c17) >>> : " + Integer.toBinaryString(c17));
		System.out.println("Integer.toOctalString(c17) >>> : " + Integer.toOctalString(c17));
		System.out.println("char c17 >>> : " + c17);
		System.out.println("Integer.toHexString(c17) >>> : \n" + Integer.toHexString(c17));

		char c18 = str.charAt(18);
		System.out.println("Integer.toBinaryString(c18) >>> : " + Integer.toBinaryString(c18));
		System.out.println("Integer.toOctalString(c18) >>> : " + Integer.toOctalString(c18));
		System.out.println("char c18 >>> : " + c18);
		System.out.println("Integer.toHexString(c18) >>> : \n" + Integer.toHexString(c18));

		char c19 = str.charAt(19);
		System.out.println("Integer.toBinaryString(c19) >>> : " + Integer.toBinaryString(c19));
		System.out.println("Integer.toOctalString(c19) >>> : " + Integer.toOctalString(c19));
		System.out.println("char c19 >>> : " + c19);
		System.out.println("Integer.toHexString(c19) >>> : \n" + Integer.toHexString(c19));

		char c20 = str.charAt(20);
		System.out.println("Integer.toBinaryString(c20) >>> : " + Integer.toBinaryString(c20));
		System.out.println("Integer.toOctalString(c20) >>> : " + Integer.toOctalString(c20));
		System.out.println("char c20 >>> : " + c20);
		System.out.println("Integer.toHexString(c20) >>> : \n" + Integer.toHexString(c20));

		char c21 = str.charAt(21);
		System.out.println("Integer.toBinaryString(c21) >>> : " + Integer.toBinaryString(c21));
		System.out.println("Integer.toOctalString(c21) >>> : " + Integer.toOctalString(c21));
		System.out.println("Char c21 >>> : " + c21);
		System.out.println("Integer.toHexString(c21) >>> : \n" + Integer.toHexString(c21));

		char c22 = str.charAt(22);
		System.out.println("Integer.toBinaryString(c22) >>> : " + Integer.toBinaryString(c22));
		System.out.println("Integer.toOctalString(c22) >>> : " + Integer.toOctalString(c22));
		System.out.println("char c22 >>> : " + c22);
		System.out.println("Integer.toHexString(c22) >>> : \n" + Integer.toHexString(c22));

		char c23 = str.charAt(23);
		System.out.println("Integer.toBinaryString(c23) >>> : " + Integer.toBinaryString(c23));
		System.out.println("Integer.toOctalString(c23) >>> : " + Integer.toOctalString(c23));
		System.out.println("char c23 >>> : " + c23);
		System.out.println("Integer.toHexString(c23) >>> : \n" + Integer.toHexString(c23));

		char c24 = str.charAt(24);
		System.out.println("Integer.toBinaryString(c24) >>> : " + Integer.toBinaryString(c24));
		System.out.println("Integer.toOctalString(c24) >>> : " + Integer.toOctalString(c24));
		System.out.println("char c24 >>> : " + c24);
		System.out.println("Integer.toHexString(c24) >>> : \n" + Integer.toHexString(c24));

		char c25 = str.charAt(25);
		System.out.println("Integer.toBinaryString(c25) >>> : " + Integer.toBinaryString(c25));
		System.out.println("Integer.toOctalString(c25) >>> : " + Integer.toOctalString(c25));
		System.out.println("char c25 >>> : " + c25);
		System.out.println("Integer.toHexString(c25) >>> : \n" + Integer.toHexString(c25));
		

		System.out.println("str.length() >>> : " + str.length());
		for (int i=0; i < str.length(); i++)
		{
			char c= str.charAt(i);
			System.out.print(Integer.toBinaryString(c) + " : ");
			System.out.print(Integer.toOctalString(c) + " : ");
			System.out.print((int)c + " : ");
			System.out.print("0x" + Integer.toHexString(c) + " : ");
			System.out.println(c);
		}
	}
}
