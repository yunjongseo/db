package a.b.c.ch4;

public interface D_interface
{
	public void d();
}