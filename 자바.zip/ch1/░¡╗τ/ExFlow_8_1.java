// package
package a.b.c.ch3;

// import


public class ExFlow_8_1
{
	// ��� 
	// �������
	// ������

	// �Լ� 

	// main() �Լ� : ���α׷� ������
	public static void main(String[] args) {
		// TODO Auto-generated method stub.

		for (int i=0; i < 3; i++ )
		{
			System.out.print((i < 3) + " : ");
			//System.out.println(i++);
			System.out.println("for i >>> : " + i);	
		}
		System.out.println("################");	
		for (int i=0; i <= 3; i++ )
		{
			System.out.print((i <= 3) + " : ");
			//System.out.println(i++);
			System.out.println("for i >>> : " + i);	
		}
	}
}
