package a.b.c.ch4;

public interface B_interface
{
	public void b();
}