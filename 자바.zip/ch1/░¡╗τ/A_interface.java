package a.b.c.ch4;

public interface A_interface
{
	public void a();
}