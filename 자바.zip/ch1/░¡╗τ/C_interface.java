package a.b.c.ch4;

public interface C_interface extends D_interface
{
	public void c();
}