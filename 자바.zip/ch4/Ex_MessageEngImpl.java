// package
package a.b.c.ch4;
// import

// �ڽ� Ŭ����
public class Ex_MessageEngImpl implements Ex_MessageInterface{

	@Override
	public void sayHello(String name){
		System.out.println("Hello, " + name + "!!");
	}
}
