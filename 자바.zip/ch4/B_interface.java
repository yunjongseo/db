// package
package a.b.c.ch4;
// import

public interface B_interface {
	public void b();
}
