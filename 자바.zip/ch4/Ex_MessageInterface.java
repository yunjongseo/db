// package
package a.b.c.ch4;
// import

public interface Ex_MessageInterface
{
	public void sayHello(String name);
}
