// package
package a.b.c.ch4;
// import

public class ConstTest_1 extends java.lang.Object {
	public ConstTest_1(){
		System.out.println("\nConstTest_1() ������ >>> : ");
	}

	public ConstTest_1(String name){
		System.out.println("\nConstTest_1(String name) ������ >>> : ");
		System.out.println("ConstTest_1() ������ name >>> : " + name);
	}

}
