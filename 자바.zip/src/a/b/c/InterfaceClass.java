package a.b.c;

public interface InterfaceClass {

	public void a();
	public int b();
	public String c();
	public boolean d();
}
