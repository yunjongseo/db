package a.b.c;

public abstract class AbstractClass {

	public abstract void aM();
}
