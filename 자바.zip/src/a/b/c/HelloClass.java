package a.b.c;

public class HelloClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("HelloClass ~~ !!");
		System.out.println("args[0] >>> : " + args[0]);
		System.out.println("args[1] >>> : " + args[1]);
	}

}
