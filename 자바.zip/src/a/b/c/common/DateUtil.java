package a.b.c.common;

import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class DateUtil {

	public static String yyyyMMdd() {
		return new SimpleDateFormat("yyyyMMdd").format(new Date()).toString();
	}
	
	public static String cTime() {
		
		// currentTimeMillis : �ð��� �и��ʷ� �޴� �Լ�
		long time = System.currentTimeMillis();
		
//		java.text.SimpleDateFormat sdf = 
//				new java.text.SimpleDateFormat("yyyy.MM.dd hh:mm:ss");
//		String cTime = sdf.format(new java.util.Date(time));
//		return cTime;
		
		return new SimpleDateFormat("yyyy.MM.dd hh:mm:ss").format(new Date(time)).toString();
		}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String d = DateUtil.yyyyMMdd();
		System.out.println("d >>> : " + d);
	}	
}

