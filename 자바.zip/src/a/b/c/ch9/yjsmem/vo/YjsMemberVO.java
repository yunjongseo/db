package a.b.c.ch9.yjsmem.vo;

import a.b.c.common.CodeUtil;

public class YjsMemberVO {

	// private : ���� ������ : class �ۿ��� ��� �Ұ���
	// �������� ù ���ڰ� �ҹ���
	private String ynum;
	private String yname;
	private String yid;
	private String ypw;
	private String ybirth;
	private String ygender;
	private String ytel;
	private String yhp;
	private String yemail;
	private String yaddr;
	private String yhobby;
	private String yphoto;
	private String yskill;
	private String yjob;
	private String deleteyn;
	private String insertdate;
	private String updatedate;
	
	public YjsMemberVO() {
	}
	
	
	public YjsMemberVO(String ynum, String yname, 
					   String yid, String ypw, 
					   String ybirth, String ygender, 
					   String ytel,String yhp, 
					   String yemail, String yaddr, 
					   String yhobby,
					   String yphoto, String yskill,
					   String yjob, String deleteyn, 
					   String insertdate, String updatedate) {
		
		this.ynum = ynum;
		this.yname = yname;
		this.yid = yid;
		this.ypw = ypw;
		this.ybirth = ybirth;
		this.ygender = ygender;
		this.ytel = ytel;
		this.yhp = yhp;
		this.yemail = yemail;
		this.yaddr = yaddr;
		this.yhobby = yhobby;
		this.ynum = ynum;
		this.yphoto = yphoto;
		this.yskill = yskill;
		this.yjob = yjob;
		this.deleteyn = deleteyn;
		this.insertdate = insertdate;
		this.updatedate = updatedate;
	}


	// getter
	public String getYnum() {
		return ynum;
	}
	public String getYname() {
		return yname;
	}
	public String getYid() {
		return yid;
	}
	public String getYpw() {
		return ypw;
	}
	public String getYbirth() {
		return ybirth;
	}
	public String getYgender() {
		return ygender;
	}
	public String getYtel() {
		return ytel;
	}
	public String getYhp() {
		return yhp;
	}
	public String getYemail() {
		return yemail;
	}
	public String getYaddr() {
		return yaddr;
	}
	public String getYhobby() {
		return yhobby;
	}
	public String getYphoto() {
		return yphoto;
	}
	public String getYskill() {
		return yskill;
	}
	public String getYjob() {
		return yjob;
	}
	public String getDeleteyn() {
		return deleteyn;
	}
	public String getInsertdate() {
		return insertdate;
	}
	public String getUpdatedate() {
		return updatedate;
	}
	
	// setter
	public void setYnum(String ynum) {
		this.ynum = ynum;
	}
	public void setYname(String yname) {
		this.yname = yname;
	}
	public void setYid(String yid) {
		this.yid = yid;
	}
	public void setYpw(String ypw) {
		this.ypw = ypw;
	}
	public void setYbirth(String ybirth) {
		this.ybirth = ybirth;
	}
	public void setYgender(String ygender) {
		this.ygender = ygender;
	}
	public void setYtel(String ytel) {
		this.ytel = ytel;
	}
	public void setYhp(String yhp) {
		this.yhp = yhp;
	}
	public void setYemail(String yemail) {
		this.yemail = yemail;
	}
	public void setYaddr(String yaddr) {
		this.yaddr = yaddr;
	}
	public void setYhobby(String yhobby) {
		this.yhobby = yhobby;
	}
	public void setYphoto(String yphoto) {
		this.yphoto = yphoto;
	}
	public void setYskill(String yskill) {
		this.yskill = yskill;
	}
	public void setYjob(String yjob) {
		this.yjob = yjob;
	}
	public void setDeleteyn(String deleteyn) {
		this.deleteyn = deleteyn;
	}
	public void setInsertdate(String insertdate) {
		this.insertdate = insertdate;
	}
	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}

	// YjsMemberVO ����Ʈ �Լ�
	public static void printYjsMemberVO(YjsMemberVO yvo) {
		
		System.out.print(yvo.getYnum()         	 + ", ");
		System.out.print(yvo.getYname()          + ", ");
		System.out.print(yvo.getYid()            + ", ");
		System.out.print(yvo.getYpw()            + ", ");
		System.out.print(CodeUtil.birth(yvo.getYbirth())    + ", ");
		System.out.print(CodeUtil.gender(yvo.getYgender())  + ", ");
		System.out.print(CodeUtil.tel(yvo.getYtel())        + ", ");
		System.out.print(CodeUtil.hp(yvo.getYhp())          + ", ");
		System.out.print(yvo.getYemail()         + ", ");
		System.out.print(yvo.getYaddr( )         + ", ");
		System.out.print(CodeUtil.hobby(yvo.getYhobby())    + ", ");
		System.out.print(yvo.getYphoto()         + ", ");
		System.out.print(yvo.getYskill()         + ", ");
		System.out.print(CodeUtil.job(yvo.getYjob())        + ", ");
		System.out.print(yvo.getDeleteyn()         + ", ");
		System.out.print(yvo.getInsertdate()         + ", ");
		System.out.println(yvo.getUpdatedate());
	}
	
	public static void printlnYjsMemberVO(YjsMemberVO yvo) {
		
		System.out.println("yvo.getYnum()    	 >>> : " + yvo.getYnum());
		System.out.println("yvo.getYname()   	 >>> : " + yvo.getYname());
		System.out.println("yvo.getYid()  		 >>> : " + yvo.getYid());
		System.out.println("yvo.getYpw()   		 >>> : " + yvo.getYpw());
		System.out.println("yvo.getYbirth()      >>> : " + yvo.getYbirth());
		System.out.println("yvo.getYgender()     >>> : " + yvo.getYgender());
		System.out.println("yvo.getYtel()     	 >>> : " + yvo.getYtel());
		System.out.println("yvo.getYhp()     	 >>> : " + yvo.getYhp());
		System.out.println("yvo.getYemail()      >>> : " + yvo.getYemail());
		System.out.println("yvo.getYaddr()    	 >>> : " + yvo.getYaddr());
		System.out.println("yvo.getYhobby()      >>> : " + yvo.getYhobby());
		System.out.println("yvo.getYphoto()      >>> : " + yvo.getYphoto());
		System.out.println("yvo.getYskill()      >>> : " + yvo.getYskill());
		System.out.println("yvo.getYjob()     	 >>> : " + yvo.getYjob());
		System.out.println("yvo.getDeleteyn()    >>> : " + yvo.getDeleteyn());
		System.out.println("yvo.getInsertdate()  >>> : " + yvo.getInsertdate());
		System.out.println("yvo.getUpdatedate()  >>> : " + yvo.getUpdatedate());
	}
}
