package a.b.c.ch9.yjsmem.sql;

public class YjsMemberSqlMap {

	// ��ü ��ȸ
	public static String getYjsMemberSelectAllQuery() {
		
		StringBuffer sb = new StringBuffer();
		sb.append(" SELECT  							\n");
		sb.append("      A.YNUM 		YNUM			\n");
		sb.append("		,A.YNAME		YNAME			\n");
		sb.append("		,A.YID			YID				\n");
		sb.append("		,A.YPW			YPW				\n");
		sb.append("		,A.YBIRTH		YBIRTH			\n");
		sb.append("		,A.YGENDER		YGENDER			\n");
		sb.append("		,A.YTEL			YTEL			\n");
		sb.append("		,A.YHP			YHP				\n");
		sb.append("		,A.YEMAIL		YEMAIL			\n");
		sb.append("		,A.YADDR		YADDR			\n");
		sb.append("		,A.YHOBBY		YHOBBY			\n");
		sb.append("		,A.YPHOTO		YPHOTO			\n");
		sb.append("		,A.YSKILL		YSKILL			\n");
		sb.append("		,A.YJOB			YJOB			\n");
		sb.append("		,A.DELETEYN		DELETEYN		\n");
		sb.append("		,TO_CHAR(A.INSERTDATE, 'YYYY-MM-DD')  INSERTDATE	\n");
		sb.append("		,TO_CHAR(A.UPDATEDATE, 'YYYY-MM-DD')  UPDATEDATE	\n");
		sb.append("	FROM								\n");
		sb.append("		 YJS_MEMBER	A					\n");
		sb.append("	WHERE DELETEYN = 'Y'				\n");
		sb.append("	ORDER BY 1 DESC 					\n");
		
		return sb.toString();
	}
	
	// ��ü ��ȸ
	public static String getYjsMemberSelectQuery() {
		
		StringBuffer sb = new StringBuffer();
		sb.append(" SELECT  							\n");
		sb.append("      A.YNUM 		YNUM			\n");
		sb.append("		,A.YNAME		YNAME			\n");
		sb.append("		,A.YID			YID				\n");
		sb.append("		,A.YPW			YPW				\n");
		sb.append("		,A.YBIRTH		YBIRTH			\n");
		sb.append("		,A.YGENDER		YGENDER			\n");
		sb.append("		,A.YTEL			YTEL			\n");
		sb.append("		,A.YHP			YHP				\n");
		sb.append("		,A.YEMAIL		YEMAIL			\n");
		sb.append("		,A.YADDR		YADDR			\n");
		sb.append("		,A.YHOBBY		YHOBBY			\n");
		sb.append("		,A.YPHOTO		YPHOTO			\n");
		sb.append("		,A.YSKILL		YSKILL			\n");
		sb.append("		,A.YJOB			YJOB			\n");
		sb.append("		,A.DELETEYN		DELETEYN		\n");
		sb.append("		,TO_CHAR(A.INSERTDATE, 'YYYY-MM-DD')  INSERTDATE	\n");
		sb.append("		,TO_CHAR(A.UPDATEDATE, 'YYYY-MM-DD')  UPDATEDATE	\n");
		sb.append("	FROM								\n");
		sb.append("		 YJS_MEMBER	A					\n");
		sb.append("	WHERE DELETEYN = 'Y'				\n");
		sb.append("	AND	  A.YNUM   = ?  				\n"); // placeholder 1
		
		return sb.toString();
	}
	
	public static String getYjsMemInsertQuery() {
		// �������� ����ϴ� SELECT, INSERT, UPDATE, DELETE
		// ? : �÷��̽� Ȧ���� �� ���������� �� ó���� ����� ���� index 1�̴�
		// ���Ĵ� ������ ����
		StringBuffer sb = new StringBuffer();
		sb.append(" INSERT INTO							\n");
		sb.append(" 	YJS_MEMBER						\n");
		sb.append(" 			  (     	      	    \n");
		sb.append(" 				YNUM				\n"); // COLUMN 1
		sb.append(" 			   ,YNAME				\n"); // COLUMN 2
		sb.append(" 			   ,YID					\n"); // COLUMN 3
		sb.append(" 			   ,YPW					\n"); // COLUMN 4
		sb.append(" 			   ,YBIRTH				\n"); // COLUMN 5
		sb.append(" 			   ,YGENDER				\n"); // COLUMN 6
		sb.append(" 			   ,YTEL				\n"); // COLUMN 7
		sb.append(" 			   ,YHP					\n"); // COLUMN 8
		sb.append(" 			   ,YEMAIL				\n"); // COLUMN 9
		sb.append(" 			   ,YADDR				\n"); // COLUMN 10
		sb.append(" 			   ,YHOBBY				\n"); // COLUMN 11
		sb.append(" 			   ,YPHOTO				\n"); // COLUMN 12
		sb.append(" 			   ,YSKILL				\n"); // COLUMN 13
		sb.append(" 			   ,YJOB				\n"); // COLUMN 14
		sb.append(" 			   ,DELETEYN			\n"); // COLUMN 15
		sb.append(" 			   ,INSERTDATE			\n"); // COLUMN 16 
		sb.append(" 			   ,UPDATEDATE			\n"); // COLUMN 17
		sb.append(" 			  )						\n");
		sb.append(" 	   VALUES						\n");
		sb.append(" 			  (						\n");
		sb.append(" 			   		?				\n"); // placeholder 1
		sb.append(" 			   	   ,?				\n"); // placeholder 2
		sb.append(" 			   	   ,?				\n"); // placeholder 3
		sb.append(" 			   	   ,?				\n"); // placeholder 4
		sb.append(" 			   	   ,?				\n"); // placeholder 5
		sb.append(" 			   	   ,?				\n"); // placeholder 6
		sb.append(" 			   	   ,?				\n"); // placeholder 7
		sb.append(" 			   	   ,?				\n"); // placeholder 8
		sb.append(" 			   	   ,?				\n"); // placeholder 9
		sb.append(" 			   	   ,?				\n"); // placeholder 10
		sb.append(" 			   	   ,?				\n"); // placeholder 11
		sb.append(" 			   	   ,?				\n"); // placeholder 12 
		sb.append(" 			   	   ,?				\n"); // placeholder 13
		sb.append(" 			   	   ,?				\n"); // placeholder 14
		sb.append(" 			   	   ,'Y'				\n"); // placeholder 15
		sb.append(" 			   	   ,SYSDATE			\n"); // placeholder 16
		sb.append(" 			   	   ,SYSDATE			\n"); // placeholder 17
		sb.append(" 			  )						\n");
		
		return sb.toString();
	}
	
	// ����
	public static String getYjsMemberUpdateQuery() {
		
		StringBuffer sb = new StringBuffer();
		sb.append(" UPDATE								\n");
		sb.append(" 		YJS_MEMBER					\n");
		sb.append(" SET									\n");
		sb.append(" 		YEMAIL		= ?				\n"); // placeholder 1
		sb.append(" 	   ,YADDR		= ?				\n"); // placeholder 2
		sb.append(" 	   ,YHOBBY		= ?				\n"); // placeholder 3
		sb.append(" 	   ,YJOB		= ?				\n"); // placeholder 4
		sb.append(" 	   ,UPDATEDATE	= SYSDATE		\n");
		sb.append(" WHERE   YNUM		= ?				\n"); // placeholder 5
		sb.append(" AND     DELETEYN	= 'Y'			\n");
		
		return sb.toString();
	}
	
	// ���� : FLAG ����
	public static String getYjsMemberDeleteQuery() {
		
		StringBuffer sb = new StringBuffer();
		sb.append(" UPDATE								\n");
		sb.append(" 		YJS_MEMBER					\n");
		sb.append(" SET									\n");
		sb.append(" 		DELETEYN	= 'N'			\n");
		sb.append(" 	   ,UPDATEDATE	= SYSDATE		\n");
		sb.append(" WHERE   YNUM		= ?				\n"); // placeholder 1
		sb.append(" AND     DELETEYN	= 'Y'			\n");
		
		return sb.toString();
	}
}
