package a.b.c;

public class InterfaceClassImpl implements InterfaceClass {

	@Override
	public void a() {
		// TODO Auto-generated method stub

	}

	@Override
	public int b() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String c() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean d() {
		// TODO Auto-generated method stub
		return false;
	}

}
