package a.b.c.ch5;

import java.util.Scanner;
 
public class Ex_String_4_1 {

	public int addM(int x, int y) {
		return x + y;
	}
	
	public int subM(int x, int y) {
		return x - y;
	}
	
	public int mulM(int x, int y) {
		return x * y;
	}
	
	public int divM(int x, int y) {
		return x / y;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("��Ģ���� ���α׷��Դϴ�");
		System.out.println("�����ڸ� �������� + - * /");
		System.out.println("���α׷��� �����Ϸ��� q �Ǵ� Q�� ��������");
		
		Scanner sc = new Scanner(System.in);
		// String dx = sc.next();
		// String dy = sc.next();
		// int x = Integer.parstInt(dX);
		// int x = Integer.parstInt(dY);
		// ������ : + - * /
		
		char oper = '\u0000';
		int x = 0;
		int y = 0;
		
		while (true) {
			
			// �����ڸ� �޾� if���� ������
			oper = sc.next().charAt(0);
			
			if (0x2b == oper) {
				System.out.println("���ϱ� : >>> : ");
				x = Integer.parseInt(sc.next());
				y = Integer.parseInt(sc.next());
				
				Ex_String_4_1 es = new Ex_String_4_1();
				int addMsum = es.addM(x, y);
				System.out.println(addMsum);
			}
			if (0x2D == oper) {
				System.out.println("���� : >>> : ");
				x = Integer.parseInt(sc.next());
				y = Integer.parseInt(sc.next());
				
				Ex_String_4_1 es = new Ex_String_4_1();
				int subMsum = es.subM(x, y);
				System.out.println(subMsum);
			}
			if (0x2A == oper) {
				System.out.println("���ϱ� : >>> : ");
				x = sc.nextInt();
				y = sc.nextInt();
				
				Ex_String_4_1 es = new Ex_String_4_1();
				int mulMsum = es.mulM(x, y);
				System.out.println(mulMsum);
			}
			if (0x2F == oper) {
				System.out.println("������ : >>> : ");
				x = sc.nextInt();
				y = sc.nextInt();
				
				Ex_String_4_1 es = new Ex_String_4_1();
				int divMsum = es.divM(x, y);
				System.out.println(divMsum);
			}
			if (0x71 == oper || 0x51 == oper) {
				System.out.println("oper >>> : " + oper);
				// break;
				System.out.println("���α׷� ����");
				System.exit(0);
			}
		}
		
	}

}
