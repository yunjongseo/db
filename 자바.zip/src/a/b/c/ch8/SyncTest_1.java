package a.b.c.ch8;

import a.b.c.common.DateUtil;

public class SyncTest_1 implements Runnable {

	BankAccount_1 ac1 = new BankAccount_1();
	
	@Override
	public void run() {
		// TODO Auto-generated method stub

		System.out.println("run() �Լ� ���� >>> : ");
		
		synchronized(this) {
			System.out.println("synchronized(this) ���� ���� >>> : ");
			
			while(ac1.balance > 0) {
				System.out.println("while(ac1.balance > 0) ���� ���� >>> : ");
				// money = 100, 200, 300 �� ����
				int money = (int)(Math.random() * 3 + 1) * 100;
				ac1.withdraw(money);
				
				System.out.println("balance >>> : " + ac1.balance
									+ " : ��� �ð� >>> : "
									+ DateUtil.cTime());
			}
		}
	}

}
