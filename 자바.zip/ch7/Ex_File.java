package a.b.c.ch7;

import java.io.File;

public class Ex_File {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			File f = new File("aaaaaa.java");
			System.out.println("f >>> : " + f);
			System.out.println("f.getName() >>> : " + f.getName());
			boolean bf = f.createNewFile();
			System.out.println("bf >>> : " + bf);
		}catch(Exception e) {
		
		}
	}

}
