// package 
package a.b.c.ch5;

// import

public class Ex_Refer_3
{
	// ���
	// �������
	// ������
	Ex_Refer_3(){
		System.out.println("Ex_Refer_3 ������ >>> : ");
	}

	// �Լ�
	public void referMethod(TestVO tvo){
		System.out.println("Ex_Refer_3.referMethod() �Լ� ���� >>> : ");
		System.out.println("referMethod :: tvo >>> : " + tvo);
		System.out.println("referMethod :: tvo.getSval >>> : " + tvo.getSval());
		System.out.println("referMethod :: tvo.getIval >>> : " + tvo.getIval());
	}
	//main() �Լ� : ���α׷� ������
	public static void main(String[] args) {
		// TODO Auto-generated method stub.

		Ex_Refer_3 ef3 = new Ex_Refer_3();
		System.out.println("ef3 >>> : " + ef3);

		for (int i=1; i <= 3 ; i++)
		{
			TestVO tvo = new TestVO();
			System.out.println("\nmain :: tvo >>> : " + tvo);
			tvo.setSval(i +""+ i);
			tvo.setIval(i +""+ i + "00");
			ef3.referMethod(tvo);
		}
	}
}
