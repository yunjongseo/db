--���̺� ����
--CREATE TABLE ���̺��� ( �÷��� ������Ÿ�� ������ )
CREATE TABLE YJS_MEMBER(
     YNUM           VARCHAR2 (20)   PRIMARY KEY
    ,YNAME          VARCHAR2 (20)
    ,YID            VARCHAR2 (20)   NOT NULL
    ,YPW            VARCHAR2 (200)  NOT NULL
    ,YBIRTH         VARCHAR2 (10)
    ,YGENDER        VARCHAR2 (2)
    ,YTEL           VARCHAR2 (16)
    ,YHP            VARCHAR2 (16)
    ,YEMAIL         VARCHAR2 (200)  NOT NULL
    ,YADDR          VARCHAR2 (300)
    ,YHOBBY         VARCHAR2 (2)
    ,YPHOTO         VARCHAR2 (200)
    ,YSKILL         VARCHAR2 (100)
    ,YJOB           VARCHAR2 (2)
    ,DELETEYN       VARCHAR2 (1)    NOT NULL
    ,INSERTDATE     DATE
    ,UPDATEDATE     DATE
);

--���̺� ����
DROP TABLE YJS_MEMBER;
--�ǵ�����(COMMIT�ϸ� ROLLBACK �� ��)
ROLLBACK;
SELECT * FROM YJS_MEMBER;

--�÷��� ROW 10�� �ֱ�
INSERT INTO YJS_MEMBER VALUES ('202108050001', '������', 'aaaaaaaa', 'aaaaaaaa', 
                            '19890906', '02', '0212345678', '01012345678',
                            'aaa@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '01', 'aaaa', '�� ����', '01', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER (YNUM, YNAME, YID, YPW, YBIRTH, YGENDER, YTEL,
                        YHP, YEMAIL, YADDR, YHOBBY, YPHOTO, YSKILL,
                        YJOB, DELETEYN, INSERTDATE, UPDATEDATE)
                VALUES ('202108050002', '������', 'aaaaaaab', 'aaaaaaaa', 
                        '', '01', '0212345678', '01012345678',
                        'aab@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                        '02', 'aaaa', '�� ����', '02', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050003', '����', 'aaaaaaac', 'aaaaaaaa', 
                            '19890908', '02', '0212345678', '01012345678',
                            'aac@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '03', 'aaaa', '�� ����', '03', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER (YNUM, YNAME, YID, YPW, YBIRTH, YGENDER, YTEL,
                        YHP, YEMAIL, YADDR, YHOBBY, YPHOTO, YSKILL,
                        YJOB, DELETEYN, INSERTDATE, UPDATEDATE)
                VALUES ('202108050004', '', 'aaaaaaad', 'aaaaaaaa', 
                        '', '01', '', '',
                        'aad@aaa.com', '', 
                        '', '', '', '', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050005', '������', 'aaaaaaae', 'aaaaaaaa', 
                            '19890910', '02', '0212345678', '01012345678',
                            'aae@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '05', 'aaaa', '�� ����', '05', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050006', '����', 'aaaaaaaf', 'aaaaaaaa', 
                            '19890911', '01', '0212345678', '01012345678',
                            'aaf@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '06', 'aaaa', '�� ����', '06', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050007', '����', 'aaaaaaag', 'aaaaaaaa', 
                            '19890912', '02', '0212345678', '01012345678',
                            'aag@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '01', 'aaaa', '�� ����', '01', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050008', '�ӾӾ�', 'aaaaaaah', 'aaaaaaaa', 
                            '19890913', '01', '0212345678', '01012345678',
                            'aah@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '02', 'aaaa', '�� ����', '02', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050009', '������', 'aaaaaaai', 'aaaaaaaa', 
                            '19890914', '02', '0212345678', '01012345678',
                            'aai@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '03', 'aaaa', '�� ����', '03', 'Y', SYSDATE, SYSDATE);
                            
INSERT INTO YJS_MEMBER VALUES ('202108050010', 'âââ', 'aaaaaaaj', 'aaaaaaaa', 
                            '19890915', '01', '0212345678', '01012345678',
                            'aaj@aaa.com', '000-000 XX�� XX�� XX�� 000', 
                            '04', 'aaaa', '�� ����', '04', 'Y', SYSDATE, SYSDATE);
                            
SELECT * FROM YJS_MEMBER;
--�����ͺ��̽� ���Ͽ� ����
COMMIT;
SHOW USER;
